var searchData=
[
  ['control_5ftype',['CONTROL_Type',['../union_c_o_n_t_r_o_l___type.html',1,'']]],
  ['coredebug_5ftype',['CoreDebug_Type',['../struct_core_debug___type.html',1,'']]]
];
